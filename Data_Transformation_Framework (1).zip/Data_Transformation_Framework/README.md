
# ADP DTF ETL Framework

## Project Structure

```
/adp_dtf_etl_repo/
├── main_etl_notebook.py                 # Main ETL orchestration notebook
└── /utils/
    ├── etl_utils.py                     # Core ETL utility functions
    ├── source_reader.py                 # Source file reading logic
    ├── target_loader.py                 # Target table writing logic
    ├── transformations.py               # Aggregations + audit columns
└── /config/
    ├── Template_prototype_v5.xlsx       # ETL Configuration Template (Excel)
```

## Flow Description

- Read ETL configuration from Excel template
- Load source files to Spark DataFrames
- Apply operations, filters, mappings, joins
- Apply aggregations and add audit columns
- Write final DataFrames to target tables

## How to Run

1. Update `config/Template_prototype_v5.xlsx` as needed in the source databricks volume under this follwoing path(/Volumes/workspace_saurabhr/default/source_data/excel/)
2. Run `main_etl_notebook.py` in Databricks (or locally with PySpark)

