from typing import Dict

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.utils import AnalysisException

from utils import constants

spark = SparkSession.builder.getOrCreate()


# ‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑ internal helpers ‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑ #
def read_source_file(row: dict) -> DataFrame:
    """
    Read one physical file according to *row* (a row from metadata_info).
    """
    fmt = str(row["source_format"]).lower()
    path = row["source_path"]

    if fmt not in constants.SUPPORTED_FORMATS:
        raise ValueError(f"Unsupported format '{fmt}'")

    if fmt in {"excel", "xlsx", "xls"}:
        return (
            spark.read.format("com.crealytics.spark.excel")
            .option("header", "true")
            .option("inferSchema", "true")
            .load(path)
        )

    if fmt == "csv":
        return spark.read.option("header", "true").csv(path)

    # parquet, json, avro, …
    return spark.read.format(fmt).load(path)


# ‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑ public api ‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑‑ #
def read_sources(meta_info: list[dict]) -> Dict[str, DataFrame]:
    """
    Iterate over *metadata_info* and load every row with `is_active = Y`.
    A temporary view is created for each alias so that ad‑hoc SQL can be
    run in notebooks.
    """
    frames: Dict[str, DataFrame] = {}

    for row in meta_info:
        if str(row.get("is_active", "")).upper() != "Y":
            continue

        alias = row["alias"]

        try:
            df = read_source_file(row)
            df.createOrReplaceTempView(alias)
            frames[alias] = df
            print(f"[reader] loaded {alias} - rows={df.count()}")
        except AnalysisException as exc:
            print(f"[reader] failed to load {alias}: {exc}")
            raise

    if not frames:
        raise RuntimeError("No active sources found in metadata_info")

    return frames
