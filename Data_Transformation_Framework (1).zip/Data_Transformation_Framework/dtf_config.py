# Databricks notebook source
# MAGIC %pip install --quiet google-generativeai pandas pyarrow fsspec s3fs adlfs gcsfs
# MAGIC

# COMMAND ----------

import os
import json
import datetime
import mimetypes
import re
from pathlib import Path
from urllib.parse import urlparse
import pandas as pd
import fsspec
import google.generativeai as genai

SOURCES = [
    "https://d37ci6vzurychx.cloudfront.net/misc/taxi+_zone_lookup.csv",
    "https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2025-05.parquet",
    # "abfs://raw/mycontainer/data/2025/07/orders.csv",
    # "s3://my‑bucket/raw/2025/07/customers.csv",
]

TARGET_TABLE = "yellow_trip_enriched"
OUT_DIR = Path("config/json")


# COMMAND ----------

def detect_provider(path: str) -> tuple[str, str]:
    parsed = urlparse(path)
    scheme = parsed.scheme.lower()
    if scheme in ("http", "https"):
        return ("open_source", "url")
    if scheme in ("abfs", "abfss", "wasbs"):
        return ("azure", scheme)
    if scheme == "s3":
        return ("aws", "s3")
    if scheme == "gs":
        return ("gcp", "gcs")
    if scheme == "dbfs":
        return ("azure", "dbfs")
    return ("on_prem", "file")

# Test it
for src in SOURCES:
    print(f"{src} → {detect_provider(src)}")


# COMMAND ----------

def sniff_format(path: str) -> str:
    mime_type, _ = mimetypes.guess_type(path)
    if mime_type and "parquet" in mime_type:
        return "parquet"
    if path.lower().endswith(".parquet"):
        return "parquet"
    if path.lower().endswith(".csv"):
        return "csv"
    if path.lower().endswith(".json"):
        return "json"
    if path.lower().endswith(".avro"):
        return "avro"
    raise ValueError(f"Cannot infer file format from {path}")

# Test it
for src in SOURCES:
    print(f"{src} → {sniff_format(src)}")


# COMMAND ----------

def list_columns(path: str, file_format: str) -> list[str]:
    fs, sub_path = fsspec.core.url_to_fs(path)
    with fs.open(sub_path, "rb") as file:
        if file_format == "csv":
            return pd.read_csv(file, nrows=0).columns.tolist()
        if file_format == "parquet":
            return pd.read_parquet(file, engine="pyarrow").columns.tolist()
        if file_format == "json":
            return list(pd.read_json(file, lines=True, nrows=1).columns)
        if file_format == "avro":
            import fastavro
            reader = fastavro.reader(file)
            schema = reader.schema
            return [field["name"] for field in schema["fields"]]
    raise ValueError(f"Unsupported format {file_format}")

# Test it
for src in SOURCES:
    fmt = sniff_format(src)
    print(f"{src} → {list_columns(src, fmt)}")


# COMMAND ----------

def prepare_catalog(sources: list[str]) -> list[dict]:
    output = []
    for url in sources:
        file_format = sniff_format(url)
        columns = list_columns(url, file_format)
        cloud, source_type = detect_provider(url)
        name = re.sub(r"[^0-9A-Za-z_]+", "_", Path(url).stem).lower()
        output.append({
            "name": name,
            "path": url,
            "format": file_format,
            "columns": columns,
            "cloud_provider": cloud,
            "source_type": source_type,
        })
    return output

# Test it
datasets = prepare_catalog(SOURCES)
datasets


# COMMAND ----------

def build_prompt(
        datasets: list[dict],
        target_table: str,
        default_target_layer: str = "gold",
        default_target_format: str = "parquet"
) -> str:
    bullets = []
    for ds in datasets:
        cols = ", ".join(ds["columns"])
        bullets.append(f"""- {ds['name']}
  Cloud Provider : {ds['cloud_provider']}
  Source Type    : {ds['source_type']}
  Location       : {ds['path']}
  Format         : {ds['format']}
  Columns ({len(ds['columns'])}) : {cols}""")
    catalogue = "\n".join(bullets)

    return f"""
You are acting as an expert data engineering assistant responsible for generating a machine-readable JSON configuration for an automated Data Transformation Framework (DTF).

Below is the dynamic catalogue of {len(datasets)} source datasets:
{catalogue}

=== TASK ===

Generate a single valid JSON object (no markdown, no commentary, no code fencing) to be saved as:
data_transformation_template_<UTC-timestamp>.json

Top-level keys in the JSON must be:
- "generated_at" (ISO 8601 UTC string, e.g. "2025-08-05T14:26:31Z")
- "metadata_info" (array)
- "dtf_mapping" (array)
- "filter_join_rules" (array)

--- Section 1: metadata_info ---

Each object must use snake_case keys only. The required keys are:

- cloud_provider         (required)
- source_type            (required)
- source_path            (required) - Full URI
- alias                  (required) - lowercase snake_case alias
- source_layer           (optional, default: "raw")
- source_format          (required) - csv, parquet, json, avro, xml, etc.
- target_layer           (optional, default: "{default_target_layer}")
- target_path            (optional) - Construct using target_layer and alias
- target_format          (optional, default: "{default_target_format}")
- target_table           (required, example: "{target_table}")
- is_active              (optional, default: "Y")
- description            (optional)
- load_strategy          (optional, default: "SCD-Type2")
- load_type              (optional, default: "Full")

Note: Do not use any spaces in keys. Use load_strategy instead of "Load Strategy".

--- Section 2: dtf_mapping ---

Each entry must be a flat object and contain the following keys:

- target_table
- target_db
- target_column
- source_column
- derived_column (null if not applicable)
- source_table
- is_active
- rule_type (e.g., direct_mapping, lead, lag, aggregation, etc.)
- condition (null if not applicable)
- order_by_cols (null if not applicable)
- lookup_cols (null if not applicable)
- group_cols (null if not applicable)
- description
- source_column_description
- target_column_description

Requirements:
- Use null (not "NaN" or empty string) where applicable
- Include all direct mappings from fact table
- Add at least 2 descriptive columns from each dimension table
- Include at least one derived transformation (substring, concat, etc.)

--- Section 3: filter_join_rules ---

Each rule object must include these snake_case keys:

- rule_id (must be unique across the array)
- rule_type ("Filter" or "Join")
- is_active ("Y" or "N")
- filter_condition and filter_column (only for Filter)
- join_condition, driving_table, driver_join_column, reference_table, reference_join_column, join_with_col (only for Join)
- target_table (null for Filter, fact table for Join)
- description (brief explanation)

At minimum, include:

- One active Filter rule
- One active Join rule

--- STRICT OUTPUT RULES ---

- Return only valid JSON (no comments, backticks, or markdown formatting)
- Keys must match exactly as specified (case-sensitive, no extra spaces)
- All values must be valid JSON (use null where needed, never "NaN")
- Output must be parseable and ready to write to file without post-processing
"""


# COMMAND ----------

# Step 1: Build the prompt using the datasets and target table
prompt = build_prompt(datasets, target_table=TARGET_TABLE)

# Step 2: Configure Gemini API
import google.generativeai as genai
api_key = "AIzaSyBY2CxN89nuhQN-56-smqtx9LpgQhoLp68"
genai.configure(api_key=api_key)

# Step 3: Load the Gemini model
model = genai.GenerativeModel("gemini-2.5-flash")

# Step 4: Generate content from Gemini using the prompt
response = model.generate_content(prompt)
raw_output = response.text.strip()

# Optional: print full output to inspect issues if decoding fails
print("Gemini raw output preview:")
print(repr(raw_output[:300]))

# Step 5: Clean up markdown formatting if Gemini adds code block
if raw_output.startswith("```json"):
    raw_output = raw_output.removeprefix("```json").removesuffix("```").strip()

# Step 6: Validate JSON structure and parse
import json
if not raw_output or not raw_output.startswith("{"):
    raise ValueError("Gemini output is not valid JSON. Please check prompt and response.")

try:
    config = json.loads(raw_output)
except json.JSONDecodeError as e:
    print("JSON decoding failed. Please check Gemini output format.")
    raise e

# Step 7: Save config file using target table name
from pathlib import Path
OUT_DIR.mkdir(parents=True, exist_ok=True)
config_path = OUT_DIR / f"{TARGET_TABLE}.json"
with open(config_path, "w") as f:
    json.dump(config, f, indent=2)

# Step 8: Export environment variable for downstream access
import os
os.environ["DTF_CONFIG_JSON"] = str(config_path)

# Final confirmation
print(f"Configuration saved to: {config_path}")


# COMMAND ----------

