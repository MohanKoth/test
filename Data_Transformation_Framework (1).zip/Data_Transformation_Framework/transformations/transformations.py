from typing import Dict

from pyspark.sql import DataFrame
from utils import etl_utils


def transform(
    source_dfs: Dict[str, DataFrame],
    mapping_rules: list[dict],
    filter_join_rules: list[dict],
) -> DataFrame:
    """
    1. Apply column level mapping rules.
    2. Apply joins and row filters.
    """
    mapped_frames = etl_utils.apply_mapping_rules(source_dfs, mapping_rules)
    final_df = etl_utils.apply_join_filter_rules(mapped_frames, filter_join_rules)
    return final_df
