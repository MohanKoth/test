# Databricks notebook source
from __future__ import annotations

import importlib
import importlib.util as iu
import inspect
import os
import shlex
import subprocess
import sys
from pathlib import Path

try:
    _here = Path(__file__)
except NameError:
    _here = Path(inspect.getsourcefile(lambda: 0))     # type: ignore[arg-type]

ROOT = next(p for p in [Path.cwd(), *_here.parents] if (p / "tests").is_dir())
print(f"[run_tests] repo root = {ROOT}")
sys.path.insert(0, str(ROOT))

for pkg in ("utils", "source_reader", "transformations", "target_loader"):
    (ROOT / pkg / "__init__.py").touch(exist_ok=True)
    importlib.import_module(pkg)

(ROOT / "tests" / "__init__.py").touch(exist_ok=True)
sys.modules["conftest"] = importlib.import_module("tests.conftest")

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

DEV = [
    "pytest", "pytest-flake8", "pytest-black", "pytest-isort",
    "flake8", "black", "isort", "radon",
]
missing = [p for p in DEV if iu.find_spec(p) is None]
if missing:
    subprocess.run(shlex.split("pip install --quiet " + " ".join(missing)), check=True)

import pytest  # noqa: E402

rc = pytest.main([str(ROOT / "tests"), "-q", "-p", "no:cacheprovider"])
if rc == 0:
    print("[run_tests] all quality gate tests passed")
else:
    raise SystemExit(f"[run_tests] pytest exit code {rc}")