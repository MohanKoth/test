# Databricks notebook source
# MAGIC %pip install --quiet openpyxl pandas time-uuid google-generativeai pyarrow fsspec s3fs adlfs gcsfs

# COMMAND ----------

# Imports and Spark session
import json
import uuid
import warnings
import datetime
from time_uuid import TimeUUID
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType

from utils import constants
from utils.etl_utils import (
    write_audit_log,
    add_audit_columns,
    incremental_delta_load,
    load_data_lineage,
    write_data_lineage )

from source_reader.source_reader import read_sources
from transformations.transformations import transform
from target_loader.target_loader import write_target

# silence openpyxl timer warnings
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

spark = SparkSession.builder.getOrCreate()

run_id = str(TimeUUID(str(uuid.uuid4())).with_utcnow())
job_name = (
    dbutils.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
start_ts = datetime.datetime.utcnow()

print(f"=== DTF RUN {run_id}  {job_name} ===")
print(f"Started at {start_ts:%Y-%m-%d %H:%M:%S UTC}")

# COMMAND ----------

# Generate JSON snapshot using Gemini AI
from generate_config_from_gemini import generate_json_config_from_gemini
from utils.constants import SOURCES, TARGET_TABLE, CONFIG_OUT_DIR, GEMINI_API_KEY
import os

print("Using Gemini AI to generate configuration...")
os.environ["GEMINI_API_KEY"] = GEMINI_API_KEY
cfg_path = generate_json_config_from_gemini(SOURCES, TARGET_TABLE, CONFIG_OUT_DIR)
print(f"Using config snapshot: {cfg_path}")

with open(cfg_path) as fh:
    cfg = json.load(fh)

print(
    f"metadata rows: {len(cfg['metadata_info'])}, "
    f"mapping rules: {len(cfg['dtf_mapping'])}, "
    f"filter / join rules: {len(cfg['filter_join_rules'])}"
)