from pathlib import Path
import os

# ───────────────────────── project root ──────────────────────────
# …/Data_Transformation_Framework
PROJECT_ROOT: Path = Path(__file__).resolve().parents[1]

# Allow users or CI to override the config directory
CONFIG_DIR: Path = Path(
    os.getenv("DTF_CONFIG_DIR", PROJECT_ROOT / "config")
).expanduser()
CONFIG_DIR.mkdir(parents=True, exist_ok=True)

# ── template & generated JSON snapshots
TEMPLATE_NAME = "data_transformation_template_streaming_joined.xlsx"
EXCEL_PATH: Path = CONFIG_DIR / TEMPLATE_NAME
JSON_DIR: Path = CONFIG_DIR / "json"
JSON_DIR.mkdir(exist_ok=True)

# ── misc runtime settings
RETENTION_DAYS: int = 90
EXCEL_ENGINE: str = "openpyxl"

# ── audit
CATALOG: str = "workspace_adp"
AUDIT_TABLE: str = f"{CATALOG}.gold.audit_logs"
DATA_LINEAGE_TABLE: str = f"{CATALOG}.gold.data_lineage"

# ── supported file formats for source ingestion
SUPPORTED_FORMATS: set[str] = {
    "csv",
    "parquet",
    "json",
    "avro",
    "excel",
    "xlsx",
}


SOURCES = [
    "https://d37ci6vzurychx.cloudfront.net/misc/taxi+_zone_lookup.csv",
    "https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2025-05.parquet"
]

TARGET_TABLE = "yellow_trip_enriched"
CONFIG_OUT_DIR = "config/json"
GEMINI_API_KEY = "AIzaSyBY2CxN89nuhQN-56-smqtx9LpgQhoLp68"

