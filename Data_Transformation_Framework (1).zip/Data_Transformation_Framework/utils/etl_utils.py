"""
ETL helper functions used across the framework.

Public API:
    * generate_json_config
    * apply_mapping_rules
    * apply_join_filter_rules
    * add_audit_columns
    * write_audit_log
    * safe_split
    * sanitize_col
"""

from __future__ import annotations

import ast
import json
import math
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List
from pyspark.sql.functions import current_timestamp, col, lit, when, concat
from delta.tables import DeltaTable

import pandas as pd
from pyspark.sql import (
    DataFrame,
    SparkSession,
    Window,
    functions as F,
)
from pyspark.sql.types import BooleanType

from utils import constants

# Spark session is created once and reused
spark = SparkSession.builder.getOrCreate()


# ───────────────────── JSON template helpers ───────────────────── #
def latest_json() -> Path | None:
    """Return the newest JSON file in CONFIG_DIR/json or *None*."""
    files = sorted(
        constants.JSON_DIR.glob("*.json"),
        key=os.path.getmtime,
        reverse=True,
    )
    return files[0] if files else None


def template_is_newer(excel: Path, json_path: Path | None) -> bool:
    """True when *excel* is newer than the cached *json_path* snapshot."""
    return json_path is None or os.path.getmtime(excel) > os.path.getmtime(json_path)


def purge_old_json(days: int = constants.RETENTION_DAYS) -> None:
    """Delete JSON snapshots older than *days* from the json folder."""
    cutoff = time.time() - days * 86_400
    for fp in constants.JSON_DIR.glob("*.json"):
        if os.path.getmtime(fp) < cutoff:
            fp.unlink(missing_ok=True)


def generate_json_config() -> Path:
    """
    Convert the Excel template to a JSON snapshot.

    Re creates the JSON only when the XLSX is newer than the last
    generated snapshot.  Returns the path of the snapshot being used.
    """
    excel = constants.EXCEL_PATH
    json_path = latest_json()
    if not template_is_newer(excel, json_path):
        return json_path

    sheets = pd.read_excel(
        excel,
        sheet_name=[
            "metadata_info",
            "dtf_mapping",
            "filter_join_rules",
        ],
        engine=constants.EXCEL_ENGINE,
    )
    payload = {
        "generated_at": datetime.utcnow().isoformat(timespec="seconds"),
        "metadata_info": sheets["metadata_info"].to_dict("records"),
        "dtf_mapping": sheets["dtf_mapping"].to_dict("records"),
        "filter_join_rules": sheets["filter_join_rules"].to_dict("records"),
    }
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%S")
    out_file = constants.JSON_DIR / f"{excel.stem}_{ts}.json"
    out_file.write_text(json.dumps(payload, indent=2))

    purge_old_json()
    return out_file


# ────────────────────────── helpers ───────────────────────── #
def clean_value(value):
    """Return a trimmed string or *None* (also turns NaN into None)."""
    if value is None:
        return None
    if isinstance(value, float) and math.isnan(value):
        return None
    txt = str(value).strip()
    return txt or None


def safe_split(text: str | None) -> list[str]:
    """Split a comma separated string safely."""
    return [t.strip() for t in text.split(",")] if text else []


def sanitize_col(col: str) -> str:
    """Turn  Any Column  Nameany_column_name."""
    return re.sub(r"__+", "_", col.strip().lower().replace(" ", "_"))


def normalise_keys(record: dict) -> dict:
    """Lower case and snake case every key in record  (single level)."""
    return {sanitize_col(k): v for k, v in record.items()}


# ────────────────── single mapping‑rule executor ────────────────── #
def apply_single_rule(df: DataFrame, rule: dict, rule_idx: int) -> DataFrame:
    """
    Execute one mapping rule against *df*.  Supports all rule types
    present in the template.
    """
    r = normalise_keys(rule)
    rule_type = (clean_value(r.get("rule_type")) or "").lower()

    src_cols = safe_split(clean_value(r.get("source_column")))
    tgt_cols = safe_split(clean_value(r.get("target_column")))
    condition = clean_value(r.get("condition"))

    # Grouping / ordering helpers (mostly for window functions)
    group_cols = [
        sanitize_col(c)
        for c in safe_split(clean_value(r.get("group_by_cols") or r.get("group_cols")))
    ]
    order_cols = [
        sanitize_col(c)
        for c in safe_split(clean_value(r.get("order_by_cols") or r.get("order_by_col")))
    ]
    lookup_col = clean_value(r.get("lookup_col") or r.get("lookup_cols"))

    print(
        f"[mapping] rule {rule_idx:>2} | "
        f"type={rule_type:<18} src={src_cols} tgt={tgt_cols} cond={condition}"
    )

    # Straight copy or Direct mapping
    if rule_type in {"direct_mapping", "Direct_mapping"}:
        return df.withColumn(tgt_cols[0], F.col(src_cols[0]))

    # Split a string into two columns
    if rule_type == "split":
        delimiter = condition or " "
        if len(tgt_cols) != 2:
            raise ValueError("split rule requires exactly TWO target columns")
        return (
            df.withColumn(tgt_cols[0], F.split(F.col(src_cols[0]), delimiter)[0])
            .withColumn(tgt_cols[1], F.split(F.col(src_cols[0]), delimiter)[1])
        )

    # Number formatting helpers
    if rule_type == "round_2_decimal":
        return df.withColumn(tgt_cols[0], F.round(F.col(src_cols[0]), 2))

    # Replace
    if rule_type == "replace" and condition:
        for old, new in ast.literal_eval(condition):
            df = df.withColumn(
                tgt_cols[0], F.regexp_replace(F.col(src_cols[0]), old, new)
            )
        return df

    # Concat
    if rule_type == "concat":
        return df.withColumn(
            tgt_cols[0], F.concat_ws(" ", *[F.col(c) for c in src_cols])
        )

    # Null check (filter)
    if rule_type == "null_checks":
        return df.filter(F.col(src_cols[0]).isNotNull())

    # Trimming helpers
    if rule_type == "ltrim":
        return df.withColumn(tgt_cols[0], F.ltrim(F.col(src_cols[0])))
    if rule_type == "rtrim":
        return df.withColumn(tgt_cols[0], F.rtrim(F.col(src_cols[0])))

    # Substring
    if rule_type == "substring":
        start, length = 1, 1
        if condition:
            m1 = re.search(r"start_position\s*=\s*(-?\d+)", condition)
            m2 = re.search(r"length\s*=\s*(\d+)", condition)
            if m1:
                start = int(m1.group(1))
            if m2:
                length = int(m2.group(1))
        return df.withColumn(
            tgt_cols[0], F.substring(F.col(src_cols[0]), start, length)
        )

    # Case conversion
    if rule_type == "upper":
        return df.withColumn(tgt_cols[0], F.upper(F.col(src_cols[0])))
    if rule_type == "lower":
        return df.withColumn(tgt_cols[0], F.lower(F.col(src_cols[0])))

    # Window functions (row_number, rank, dense_rank, lead, lag)
    if rule_type in {"row_number", "rank", "dense_rank", "lead", "lag"}:
        base_window = (
            Window.partitionBy(*group_cols)
            if group_cols
            else Window.partitionBy()
        )

        order_window = (
            base_window.orderBy(*[F.col(c) for c in order_cols])
            if order_cols
            else base_window.orderBy(F.lit(1))
        )

        if rule_type in {"row_number", "rank", "dense_rank"}:
            fn = {
                "row_number": F.row_number,
                "rank": F.rank,
                "dense_rank": F.dense_rank,
            }[rule_type]
            return df.withColumn(tgt_cols[0], fn().over(order_window))

        # Lead / lag
        offset = int(condition.split("=")[-1]) if condition and "=" in condition else 1
        if rule_type == "lead":
            return df.withColumn(
                tgt_cols[0],
                F.lead(F.col(lookup_col or src_cols[0]), offset).over(order_window),
            )
        return df.withColumn(
            tgt_cols[0],
            F.lag(F.col(lookup_col or src_cols[0]), offset).over(order_window),
        )

    # Aggregations
    if rule_type == "aggregation":
        fn = getattr(F, (condition or "sum").lower())
        if group_cols:
            agg_df = df.groupBy(*group_cols).agg(
                fn(F.col(src_cols[0])).alias(tgt_cols[0])
            )
            return df.join(agg_df, group_cols, "left")
        agg_value = df.select(fn(F.col(src_cols[0])).alias("v")).first()["v"]
        return df.withColumn(tgt_cols[0], F.lit(agg_value))

    # Date / time helpers
    if rule_type == "string_to_timestamp":
        return df.withColumn(
            tgt_cols[0],
            F.to_timestamp(
                F.col(src_cols[0]),
                condition or "yyyy-MM-dd HH:mm:ss",
            ),
        )
    if rule_type == "string_to_date":
        return df.withColumn(
            tgt_cols[0],
            F.to_date(F.col(src_cols[0]), condition or "yyyy-MM-dd"),
        )

    if rule_type == "get_day_week_month_year":
        col_ = F.col(src_cols[0])
        base = tgt_cols[0] or src_cols[0]
        return (
            df.withColumn(f"{base}_day", F.dayofmonth(col_))
            .withColumn(f"{base}_week", F.weekofyear(col_))
            .withColumn(f"{base}_month", F.month(col_))
            .withColumn(f"{base}_year", F.year(col_))
        )

    print("[mapping] rule produced no change")
    return df


# ───────────────── mapping / filter / join engines ───────────────── #
def apply_mapping_rules(
    dataframes: Dict[str, DataFrame], rules: List[dict]
) -> Dict[str, DataFrame]:
    """
    Apply all active mapping rules per source alias.
    """
    result: Dict[str, DataFrame] = {}
    for alias, df in dataframes.items():
        active_rules = [
            r
            for r in rules
            if str(r.get("source_table", r.get("source table", ""))).strip() == alias
            and str(r.get("is_active", r.get("is_active", ""))).upper() == "Y"
        ]
        print(f"[mapping] {alias}: {len(active_rules)} active rules")
        for idx, rule in enumerate(active_rules, start=1):
            df = apply_single_rule(df, rule, idx)
        result[alias] = df
    return result


def build_filter_expr(driver_col: str, raw_cond: str) -> str:
    """
    Craft a valid SQL expression from a driver column and a raw condition.
    """
    trimmed = raw_cond.strip()
    if driver_col and driver_col in trimmed:
        return trimmed

    op_tokens = ("=", ">", "<", "!", " like ", " in ", " between ")
    has_op = any(tok in trimmed.lower() for tok in op_tokens)

    # Plain literal e.g. London
    if not has_op:
        if not trimmed.startswith(("'", '"')):
            trimmed = f"'{trimmed}'"
        return f"{driver_col} = {trimmed}"

    starts_with_op = bool(
        re.match(r"^[<>=!]", trimmed)
    ) or trimmed.lower().startswith(("like", "in", "between"))
    return f"{driver_col} {trimmed}" if starts_with_op else trimmed


def apply_join_filter_rules(
    dataframes: Dict[str, DataFrame], rules: List[dict]
) -> DataFrame:
    """
    Execute filters and joins according to the *filter_join_rules* sheet.
    The first active row defines the driving table.
    """
    active = [normalise_keys(r) for r in rules if str(r.get("is_active", "")).upper() == "Y"]
    if not active:
        raise ValueError("No active filter/join rules")

    driving_table = active[0]["driving_table"]
    if driving_table not in dataframes:
        raise ValueError(f"Driving table '{driving_table}' not found")

    df = dataframes[driving_table]
    print(f"[join] driving table: {driving_table}")

    for rule in active:
        rule_type = rule["rule_type"].lower()

        if rule_type == "filter":
            raw_cond = clean_value(rule.get("filter_condition"))
            driver_col = clean_value(
                rule.get("filter_column") or rule.get("driver_join_column")
            )
            if raw_cond:
                expr = build_filter_expr(driver_col, raw_cond)
                df = df.filter(F.expr(expr))
                print(f"[filter] {expr}")

        elif rule_type == "join":
            right_alias = rule["reference_table"]
            left_col = clean_value(rule.get("driver_join_column"))
            right_col = clean_value(rule.get("reference_join_column"))
            join_type = (clean_value(rule.get("join_condition")) or "inner").lower()

            if not all([left_col, right_col]):
                raise ValueError(f"Join rule missing columns: {rule}")

            left_keys = {sanitize_col(c) for c in df.columns}
            right_df = dataframes[right_alias]
            right_cols = [
                c for c in right_df.columns if sanitize_col(c) not in left_keys
            ]

            df = (
                df.alias("l")
                .join(
                    right_df.alias(right_alias),
                    F.col(f"l.{left_col}") == F.col(f"{right_alias}.{right_col}"),
                    join_type,
                )
                .select("l.*", *[F.col(f"{right_alias}.{c}") for c in right_cols])
            )
            print(f"[join] {join_type.upper()} on {left_col} = {right_alias}.{right_col}")

    return df


# ──────────────────────── audit utilities ───────────────────────── #
def add_audit_columns(df: DataFrame) -> DataFrame:
    """Append or overwrite standard audit columns."""
    audit_exprs = {
        "created_date": F.current_timestamp(),
        "created_by": F.lit("System"),
        "active_flag": F.lit(True).cast(BooleanType()),
    }
    for col, expr in audit_exprs.items():
        df = df.drop(col) if col in df.columns else df
        df = df.withColumn(col, expr)
    return df


def write_audit_log(
    run_id: str,
    job_name: str,
    start_ts: datetime,
    end_ts: datetime,
    source_dfs: Dict[str, DataFrame],
    final_df: DataFrame,
) -> None:
    """Write one row per run to the central audit Delta table."""
    src_files = ",".join(source_dfs.keys())
    src_cols = sum(len(df.columns) for df in source_dfs.values())
    src_rows = sum(df.count() for df in source_dfs.values())
    final_cols = len(final_df.columns)
    final_rows = final_df.count()
    duration = (end_ts - start_ts).total_seconds()

    audit_row = spark.createDataFrame(
        [
            (
                run_id,
                job_name,
                start_ts,
                end_ts,
                duration,
                src_files,
                src_cols,
                src_rows,
                final_cols,
                final_rows,
            )
        ],
        [
            "run_id",
            "job_name",
            "run_start_utc",
            "run_end_utc",
            "execution_seconds",
            "source_files",
            "total_source_columns",
            "total_source_records",
            "final_columns",
            "final_records",
        ],
    )
    audit_row.write.mode("append").format("delta").saveAsTable(constants.AUDIT_TABLE)



# -------------Incremental load---------------------------
def incremental_delta_load(source_df, metadata_df):
    start_time = time.time()
    
    # Filter metadata for active incremental rules
    filtered_metadata = metadata_df.filter(
        (col("rule_type") == "Incremental") &
        (col("is_active") == "Y")
    )
    
    if filtered_metadata.count() == 0:
        raise ValueError("No active incremental rules found in metadata")
    
    metadata_row = filtered_metadata.first()
    schema_name = metadata_row["target_db"]
    table_name = metadata_row["target_table"]
    merge_condition = metadata_row["condition"]
    
    target_table_name = f"{schema_name}.{table_name}"
    
    print(f"Starting incremental load to {target_table_name}")
    print(f"Using merge condition: {merge_condition}")
    source_count = source_df.count()
    print(f"Source data has {source_count} rows")

    # Add processing time column
    final_df = source_df.withColumn("processing_time", current_timestamp())
    print("Added processing_time column")
    
    try:
        tables = spark.sql(f"SHOW TABLES IN {schema_name} LIKE '{table_name}'").count()
        delta_table_exists = tables > 0
        
        if delta_table_exists:
            # Check if it's a Delta table
            table_format = spark.sql(f"DESCRIBE FORMATTED {target_table_name}") \
                .filter("col_name = 'Provider'") \
                .select("data_type") \
                .collect()[0][0].lower()
            delta_table_exists = "delta" in table_format
            print(f"Delta table '{target_table_name}' exists: {delta_table_exists}")
        else:
            print(f"Table '{target_table_name}' does not exist")
    except Exception as e:
        delta_table_exists = False
        print(f"Error checking if table exists: {str(e)}")
        print(f"Will create a new Delta table '{target_table_name}'")
    
    if not delta_table_exists:
        print(f"Creating new Delta table '{target_table_name}'")
        try:
            final_df.write.format("delta").saveAsTable(target_table_name)
            print(f"New Delta table '{target_table_name}' created")
        except Exception as e:
            print(f"Failed to create Delta table: {str(e)}")
            raise
    else:
        try:
            print(f"Performing merge operation on existing Delta table '{target_table_name}'")
            delta_table = DeltaTable.forName(spark, target_table_name)
            
            print(f"Using merge condition from metadata: {merge_condition}")
            delta_table.alias("target") \
                .merge(
                    final_df.alias("source"),
                    merge_condition
                ) \
                .whenMatchedUpdateAll() \
                .whenNotMatchedInsertAll() \
                .execute()
            
            print(f"Incremental merge completed for table '{target_table_name}'")
        except Exception as e:
            print(f"Error during merge operation: {str(e)}")
    
    result_df = spark.table(target_table_name)
    
    end_time = time.time()
    result_count = result_df.count()
    print(f"Target table row count: {result_count}")
    print(f"Operation completed in {end_time - start_time:.2f} seconds")
    
    return result_df

#-------------------------- write data lineage -----------------------------

def load_data_lineage(cfg, start_ts,end_ts, run_id):
    
    dtf = spark.createDataFrame(cfg['dtf_mapping'])
    dtf = dtf.filter(dtf["is_active"] == "Y")

    filter_join = spark.createDataFrame(cfg['filter_join_rules'])
    filter_join = filter_join.filter(filter_join["is_active"] == "Y")
    
    lineage_dtf = dtf.select(["source_table","source_column","derived_column","rule_type","target_table","target_column"])

    lineage_dtf =lineage_dtf.withColumn("source_column", when(lineage_dtf['derived_column'].isin('nan', None,''),lineage_dtf['source_column']).otherwise(lineage_dtf['derived_column']))

    lineage_dtf = lineage_dtf.drop("derived_column")
    lineage_dtf = lineage_dtf.withColumnRenamed("rule_type","operation")
                         
    lineage_filter = filter_join.filter(filter_join["rule_type"].isin("Filter", "filter")) \
                            .select(["driving_table", "driver_join_column", "rule_type", "target_table"])

    lineage_filter = lineage_filter.withColumnRenamed("driving_table", "source_table") \
                        .withColumnRenamed("driver_join_column", "source_column") \
                        .withColumnRenamed("rule_type", "operation") \
                        .withColumn("target_table", 
                                    when(lineage_filter['target_table'].isin('nan', None,''), lit(None))
                                    .otherwise(lineage_filter['target_table'])) \
                        .withColumn("target_column", lit(None)) 

    lineage_join_1 = filter_join.filter(filter_join["rule_type"].isin("Join", "join")) \
    .select(["driving_table", "driver_join_column","rule_type","join_condition", "target_table"])

    lineage_join_1 = lineage_join_1.withColumnRenamed("driving_table", "source_table") \
                        .withColumnRenamed("driver_join_column", "source_column") \
                        .withColumn("operation", concat(lineage_join_1["rule_type"], lit(" | "), lineage_join_1["join_condition"])) \
                        .withColumn("target_column", lit(None)) 
                                                      
    lineage_join_2 = filter_join.filter(filter_join["rule_type"].isin("Join", "join")) \
    .select(["reference_table", "reference_join_column","rule_type","join_condition", "target_table"])

    lineage_join_2 = lineage_join_2.withColumnRenamed("reference_table", "source_table") \
                        .withColumnRenamed("reference_join_column", "source_column") \
                        .withColumn("operation", concat(lineage_join_2["rule_type"], lit(" | "), lineage_join_2["join_condition"])) \
                        .withColumn("target_column", lit(None)) 

    lineage_join = lineage_join_1.union(lineage_join_2).select(["source_table","source_column","operation","target_table","target_column"])
    
    if lineage_join.count() == 0:
        lineage_filter_join = lineage_filter
    else:
        lineage_filter_join = lineage_filter.union(lineage_join)

    if lineage_filter_join.count() == 0:
        lineage_df = lineage_dtf
    else:
        lineage_df = lineage_dtf.union(lineage_filter_join)
    
    lineage_df = lineage_df.withColumn("start_time", lit(start_ts)) \
                    .withColumn("end_time", lit(end_ts)) \
                    .withColumn("run_id", lit(run_id))                     

    return lineage_df

def write_data_lineage(lineage_df, data_lineage_path):
    try:
        print("Writing data lineage table...")
        lineage_df.write.mode("append").format('delta').saveAsTable(f"{data_lineage_path}")
        print("Data lineage table updated with new entires.")

    except Exception as e:
            print(f"Error during data lineage write operation: {str(e)}")