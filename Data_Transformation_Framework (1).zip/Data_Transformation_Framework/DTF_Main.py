# Databricks notebook source
# %run ./unit_test/run_tests.py

# COMMAND ----------

# MAGIC %pip install --quiet openpyxl pandas time-uuid

# COMMAND ----------

# Imports and Spark session
import json
import uuid
import warnings
import datetime
from time_uuid import TimeUUID
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType

from utils import constants
from utils.etl_utils import (
    generate_json_config,
    write_audit_log,
    add_audit_columns,
    incremental_delta_load,
    load_data_lineage,
    write_data_lineage )

from source_reader.source_reader import read_sources
from transformations.transformations import transform
from target_loader.target_loader import write_target

# silence openpyxl timer warnings
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

spark = SparkSession.builder.getOrCreate()

run_id = str(TimeUUID(str(uuid.uuid4())).with_utcnow())
job_name = (
    dbutils.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
start_ts = datetime.datetime.utcnow()

print(f"=== DTF RUN {run_id}  {job_name} ===")
print(f"Started at {start_ts:%Y-%m-%d %H:%M:%S UTC}")

# COMMAND ----------

# 1. Generate (or reuse) JSON snapshot of the Excel template
print("STEP 1 preparing JSON configuration")
cfg_path = generate_json_config()
print(f"Using config snapshot: {cfg_path}")

with open(cfg_path) as fh:
    cfg = json.load(fh)

print(
    f"metadata rows: {len(cfg['metadata_info'])}, "
    f"mapping rules: {len(cfg['dtf_mapping'])}, "
    f"filter / join rules: {len(cfg['filter_join_rules'])}"
)

# COMMAND ----------

# 2. Read every active source file
print("STEP 2 reading source files")
src_dfs = read_sources(cfg["metadata_info"])

print("\nSummary of loaded DataFrames")
for alias, df in src_dfs.items():
    print(f"{alias:<15} rows={df.count():>6} cols={len(df.columns):>3}")
    display(df)

# COMMAND ----------

# 3. Apply mappings, joins and filters
print("STEP 3 executing transformations")
t0 = datetime.datetime.utcnow()

final_df = transform(
    src_dfs,
    cfg["dtf_mapping"],
    cfg["filter_join_rules"],
).transform(add_audit_columns)

t1 = datetime.datetime.utcnow()
print(
    f"Transformations finished in {(t1 - t0).total_seconds():.2f} s: "
    f"{final_df.count()} rows • {len(final_df.columns)} columns"
)
display(final_df.limit(20))

# COMMAND ----------

dtf_mapping_data = cfg['dtf_mapping']
dtf_mapping_df = spark.createDataFrame(dtf_mapping_data)

if dtf_mapping_data and len(dtf_mapping_data) > 0:
    sample_keys = dtf_mapping_data[0].keys()
    schema = StructType([StructField(key, StringType(), True) for key in sample_keys])
    dtf_mapping_df = spark.createDataFrame(dtf_mapping_data, schema)
else:
    print("Warning: dtf_mapping is empty, creating empty DataFrame")
    dtf_mapping_df = spark.createDataFrame([], StructType([]))

# COMMAND ----------

incremental_delta_load(final_df, dtf_mapping_df)

# COMMAND ----------

# 4. Write to Delta targets
print("STEP 4 writing Delta targets")
write_target(
    final_df,
    cfg["metadata_info"],
    cfg["dtf_mapping"],
)
print("Delta targets written")

# COMMAND ----------

# 5. Audit log
end_ts = datetime.datetime.utcnow()
print("STEP 5 - writing audit log")
write_audit_log(run_id, job_name, start_ts, end_ts, src_dfs, final_df)
print(f"Audit row inserted into {constants.AUDIT_TABLE}")

print(
    f"=== DTF RUN {run_id} SUCCESS elapsed "
    f"{(end_ts - start_ts).total_seconds():.1f}s ==="
)

# COMMAND ----------

# 6. Data Lineage
print("STEP 6 - writing data lineage")
lineage_df = load_data_lineage(cfg,start_ts,end_ts,run_id)
write_data_lineage(lineage_df, constants.DATA_LINEAGE_TABLE)
print(f"Data Lineage updated into {constants.DATA_LINEAGE_TABLE}")

print(
    f"=== DTF Data Lineage update for RUN {run_id} : SUCCESS "
)