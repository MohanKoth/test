import os
import json
import mimetypes
import re
from pathlib import Path
from urllib.parse import urlparse
import pandas as pd
import fsspec
import google.generativeai as genai


def detect_provider(path: str):
    parsed = urlparse(path)
    scheme = parsed.scheme.lower()
    if scheme in ("http", "https"):
        return ("open_source", "url")
    if scheme in ("abfs", "abfss", "wasbs"):
        return ("azure", scheme)
    if scheme == "s3":
        return ("aws", "s3")
    if scheme == "gs":
        return ("gcp", "gcs")
    if scheme == "dbfs":
        return ("azure", "dbfs")
    return ("on_prem", "file")


def sniff_format(path: str) -> str:
    mime_type, _ = mimetypes.guess_type(path)
    if mime_type and "parquet" in mime_type:
        return "parquet"
    if path.lower().endswith(".parquet"):
        return "parquet"
    if path.lower().endswith(".csv"):
        return "csv"
    if path.lower().endswith(".json"):
        return "json"
    if path.lower().endswith(".avro"):
        return "avro"
    raise ValueError(f"Cannot infer file format from {path}")


def list_columns(path: str, file_format: str) -> list:
    fs, sub_path = fsspec.core.url_to_fs(path)
    with fs.open(sub_path, "rb") as file:
        if file_format == "csv":
            return pd.read_csv(file, nrows=0).columns.tolist()
        if file_format == "parquet":
            return pd.read_parquet(file, engine="pyarrow").columns.tolist()
        if file_format == "json":
            return list(pd.read_json(file, lines=True, nrows=1).columns)
        if file_format == "avro":
            import fastavro
            reader = fastavro.reader(file)
            schema = reader.schema
            return [field["name"] for field in schema["fields"]]
    raise ValueError(f"Unsupported format {file_format}")


def prepare_catalog(sources: list) -> list:
    output = []
    for url in sources:
        file_format = sniff_format(url)
        columns = list_columns(url, file_format)
        cloud, source_type = detect_provider(url)
        name = re.sub(r"[^0-9A-Za-z_]+", "_", Path(url).stem).lower()
        output.append({
            "name": name,
            "path": url,
            "format": file_format,
            "columns": columns,
            "cloud_provider": cloud,
            "source_type": source_type,
        })
    return output


def build_prompt(
        datasets: list[dict],
        target_table: str,
        default_target_layer: str = "gold",
        default_target_format: str = "parquet"
) -> str:
    bullets = []
    for ds in datasets:
        cols = ", ".join(ds["columns"])
        bullets.append(f"""- {ds['name']}
  Cloud Provider : {ds['cloud_provider']}
  Source Type    : {ds['source_type']}
  Location       : {ds['path']}
  Format         : {ds['format']}
  Columns ({len(ds['columns'])}) : {cols}""")
    catalogue = "\n".join(bullets)

    return f"""
You are acting as an expert data engineering assistant responsible for generating a machine-readable JSON configuration for an automated Data Transformation Framework (DTF).

Below is the dynamic catalogue of {len(datasets)} source datasets:
{catalogue}

=== TASK ===

Generate a single valid JSON object (no markdown, no commentary, no code fencing) to be saved as:
data_transformation_template_<UTC-timestamp>.json

Top-level keys in the JSON must be:
- "generated_at" (ISO 8601 UTC string, e.g. "2025-08-05T14:26:31Z")
- "metadata_info" (array)
- "dtf_mapping" (array)
- "filter_join_rules" (array)

--- Section 1: metadata_info ---

Each object must use snake_case keys only. The required keys are:

- cloud_provider         (required)
- source_type            (required)
- source_path            (required) - Full URI
- alias                  (required) - lowercase snake_case alias
- source_layer           (optional, default: "raw")
- source_format          (required) - csv, parquet, json, avro, xml, etc.
- target_layer           (optional, default: "{default_target_layer}")
- target_path            (optional) - Construct using target_layer and alias
- target_format          (optional, default: "{default_target_format}")
- target_table           (required, example: "{target_table}")
- is_active              (optional, default: "Y")
- description            (optional)
- load_strategy          (optional, default: "SCD-Type2")
- load_type              (optional, default: "Full")

--- Section 2: dtf_mapping ---

Each entry must be a flat object and contain the following keys:

- target_table
- target_db
- target_column
- source_column
- derived_column (null if not applicable)
- source_table
- is_active
- rule_type (e.g., direct_mapping, lead, lag, aggregation, etc.)
- condition (null if not applicable)
- order_by_cols (null if not applicable)
- lookup_cols (null if not applicable)
- group_cols (null if not applicable)
- description
- source_column_description
- target_column_description

Requirements:
- Use null (not "NaN" or empty string) where applicable
- Include all direct mappings from fact table
- Add at least 2 descriptive columns from each dimension table
- Include at least one derived transformation (substring, concat, etc.)

--- Section 3: filter_join_rules ---

Each rule object must include these snake_case keys:

- rule_id (must be unique across the array)
- rule_type ("Filter" or "Join")
- is_active ("Y" or "N")

For Filter rules:
- filter_condition, filter_column are required
- driving_table must be inferred from the filter_column's source dataset alias
- driver_join_column must match filter_column
- All join_* fields must be null
- target_table can be null

For Join rules:
- join_condition must be one of: "inner", "left", "right", "full", "cross" (only these, case-insensitive)
- driving_table and reference_table must match alias from metadata_info
- driver_join_column and reference_join_column must be provided
- join_with_col is the alias prefix (e.g., "dim_zone_data")
- target_table is required

At minimum, include:
- One active Filter rule
- One active Join rule

--- STRICT OUTPUT RULES ---

- Return only valid JSON (no comments, backticks, or markdown formatting)
- Keys must match exactly as specified (case-sensitive, no extra spaces)
- All values must be valid JSON (use null where needed, never "NaN")
- Output must be parseable and ready to write to file without post-processing
"""



def generate_json_config_from_gemini(sources, target_table, out_dir):
    datasets = prepare_catalog(sources)
    prompt = build_prompt(datasets, target_table)

    genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))
    model = genai.GenerativeModel("gemini-2.5-flash")
    response = model.generate_content(prompt)
    raw_output = response.text.strip()

    if raw_output.startswith("```json"):
        raw_output = raw_output.removeprefix("```json").removesuffix("```").strip()

    if not raw_output or not raw_output.startswith("{"):
        raise ValueError("Gemini output is not valid JSON.")

    config = json.loads(raw_output)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    config_path = out_dir / f"{target_table}.json"
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
    return str(config_path)
