from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Sequence

from delta.tables import DeltaTable
from pyspark.sql import DataFrame, SparkSession, Window, functions as F

from utils.etl_utils import add_audit_columns, sanitize_col, safe_split

spark = SparkSession.builder.getOrCreate()


AUDIT_SCD_COLS = {
    "created_date",
    "created_by",
    "active_flag",
    "valid_from",
    "valid_to",
    "is_current",
}


def _ensure_schema(schema_name: str) -> None:
    """
    Create catalog and schema when they do not exist.
    """
    if "." in schema_name:
        catalog, schema = schema_name.split(".", 1)
        spark.sql(f"CREATE CATALOG IF NOT EXISTS {catalog}")
        spark.sql(f"CREATE SCHEMA  IF NOT EXISTS {catalog}.{schema}")
    else:
        spark.sql(f"CREATE SCHEMA  IF NOT EXISTS {schema_name}")


def _collect_target_cols(rows: Sequence[Dict]) -> dict[str, set[str]]:
    """
    Build {target_table -> {allowed_columns}} from dtf_mapping.
    """
    out: dict[str, set[str]] = defaultdict(set)

    for r in rows or []:
        if str(r.get("is_active", "")).upper() != "Y":
            continue

        tab = sanitize_col(r.get("target_table") or "__GLOBAL__")
        raw = r.get("target_columns") or r.get("target_column") or ""
        for col in safe_split(raw):
            out[tab].add(sanitize_col(col))

    return out


def _natural_keys(df: DataFrame) -> list[str]:
    """
    Fallback business‑key heuristic: *_id columns or the first column.
    """
    ids = [c for c in df.columns if c.lower().endswith("_id") or c.lower() == "id"]
    return ids or [df.columns[0]]


def _deduplicate_source(df: DataFrame, keys: list[str]) -> DataFrame:
    """
    Keep one row per business key – the newest by valid_from, then created_date,
    otherwise the first appearance.
    """
    if "valid_from" in df.columns:
        win = Window.partitionBy(*keys).orderBy(F.col("valid_from").desc())
        return df.withColumn("_rn", F.row_number().over(win)).filter("_rn = 1").drop("_rn")

    if "created_date" in df.columns:
        win = Window.partitionBy(*keys).orderBy(F.col("created_date").desc())
        return df.withColumn("_rn", F.row_number().over(win)).filter("_rn = 1").drop("_rn")

    return df.dropDuplicates(keys)


def _drop_dupes(df: DataFrame) -> DataFrame:
    """
    Remove physically duplicated columns that differ only in capitalisation
    or whitespace after sanitising.
    """
    seen: set[str] = set()
    keep: list[str] = []

    for c in df.columns:
        sc = sanitize_col(c)
        if sc in seen:
            continue
        seen.add(sc)
        keep.append(c)

    return df.select(keep)


# SCD‑II merge
def _scd2_merge(table: str, new_df: DataFrame, keys: list[str]) -> None:
    """
    Two‑phase merge:
    1. Close the current version when any attribute changes.
    2. Insert the incoming record as the new current version.
    """
    clean_df = _deduplicate_source(new_df, keys)

    tgt = DeltaTable.forName(spark, table)
    t, s = "t", "s"

    join_cond = " AND ".join(f"{t}.{k} = {s}.{k}" for k in keys)
    join_cond = f"{join_cond} AND {t}.is_current"

    skip_cols = set(keys) | AUDIT_SCD_COLS
    diff_expr = " OR ".join(
        f"NOT({t}.{c} <=> {s}.{c})" for c in clean_df.columns if c not in skip_cols
    ) or "false"

    # close old record
    (
        tgt.alias(t)
        .merge(clean_df.alias(s), join_cond)
        .whenMatchedUpdate(
            condition=diff_expr,
            set={
                "active_flag": "false",
                "valid_to": "current_timestamp()",
                "is_current": "false",
            },
        )
        .execute()
    )

    # insert new record
    (
        tgt.alias(t)
        .merge(clean_df.alias(s), join_cond)
        .whenNotMatchedInsert(values={c: f"{s}.{c}" for c in clean_df.columns})
        .execute()
    )


# main entry point
def write_target(
    df: DataFrame,
    meta_info: List[Dict],
    mapping_rules: List[Dict] | None = None,
) -> None:
    """
    Write a transformed DataFrame to every active target table defined in
    metadata_info.  Supports overwrite or SCD‑Type 2 merge.
    """
    active = [r for r in meta_info if str(r.get("is_active", "")).upper() == "Y"]
    if not active:
        raise ValueError("metadata_info contains no active targets")

    table_cols = _collect_target_cols(mapping_rules)

    base = (
        _drop_dupes(df)
        .transform(add_audit_columns)
        .withColumn("valid_from", F.current_timestamp())
        .withColumn("valid_to", F.to_timestamp(F.lit("9999-12-31 23:59:59")))
        .withColumn("is_current", F.lit(True))
    )

    grouped: dict[tuple, dict] = {}
    for r in active:
        key = (
            r["target_layer"].strip(),
            r["target_table"].strip(),
            str(r.get("target_path", "")).strip(),
            str(r.get("target_format", "")).lower(),
        )
        grouped.setdefault(key, r)

    for (layer, tbl, path, _fmt_in), row in grouped.items():
        full_name = f"{layer}.{tbl}"
        _ensure_schema(layer)

        allowed = (
            table_cols.get(sanitize_col(tbl), set())
            | table_cols.get("__GLOBAL__", set())
        )

        cols_to_write = (
            base.columns
            if not allowed
            else [
                c
                for c in base.columns
                if sanitize_col(c) in allowed or sanitize_col(c) in AUDIT_SCD_COLS
            ]
        )

        df_out = base.select(cols_to_write)

        keys = [
            sanitize_col(c) for c in safe_split(row.get("business_key_columns"))
        ] or _natural_keys(df_out)

        strategy = str(row.get("load_strategy", "")).lower().replace(" ", "_")
        needs_scd2 = strategy in {"scd_type2", "scd2", "type2"} or bool(keys)

        external = bool(path)
        fmt = "delta" if not external else str(row.get("target_format", "delta")).lower()

        writer = df_out.repartition(1).write

        if spark.catalog.tableExists(full_name):
            if needs_scd2:
                _scd2_merge(full_name, df_out, keys)
            else:
                (
                    writer.mode("overwrite")
                    .format(fmt)
                    .option("mergeSchema", "true")
                    .saveAsTable(full_name)
                )
            continue

        try:
            if external:
                (
                    writer.mode("overwrite")
                    .format(fmt)
                    .option("mergeSchema", "true")
                    .save(path)
                )
                spark.sql(
                    f"CREATE TABLE IF NOT EXISTS {full_name} "
                    f"USING {fmt.upper()} LOCATION '{path}'"
                )
            else:
                (
                    writer.mode("overwrite")
                    .format("delta")
                    .option("mergeSchema", "true")
                    .saveAsTable(full_name)
                )
        except Exception:
            (
                writer.mode("overwrite")
                .format("delta")
                .option("mergeSchema", "true")
                .saveAsTable(full_name)
            )

    print("[writer] targets updated")
