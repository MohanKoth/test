"""
Shared helpers for repository-wide tests.
"""
from pathlib import Path
import importlib

# Top‑level packages that hold source code
CODE_ROOTS = ["utils", "source_reader", "transformations", "target_loader"]


def iter_module_names():
    """
    Yield every fully qualified module name inside CODE_ROOTS.
    """
    for root in CODE_ROOTS:
        for path in Path(root).rglob("*.py"):
            if path.name.startswith("__"):
                continue
            parts = path.with_suffix("").parts
            yield ".".join(parts)


def import_module(name: str):
    return importlib.import_module(name)
