"""
Fail when less than 80% of public members have a docstring.
"""
import inspect
from tests.conftest import iter_module_names, import_module


def public_members(module):
    for name, obj in inspect.getmembers(module):
        if name.startswith("_"):
            continue
        if inspect.isclass(obj) or inspect.isfunction(obj):
            yield obj


def test_docstring_coverage():
    total = missing = 0
    for mod_name in iter_module_names():
        mod = import_module(mod_name)
        total += 1
        if not (mod.__doc__ or "").strip():
            missing += 1
        for member in public_members(mod):
            total += 1
            if not (member.__doc__ or "").strip():
                missing += 1

    coverage = 100 * (1 - missing / total) if total else 100
    assert coverage >= 80, f"Docstring coverage only {coverage:.1f}% (< 80%)"
