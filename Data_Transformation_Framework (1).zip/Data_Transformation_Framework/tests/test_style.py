"""
Style gates - fail the test run if black, flake8 or isort complain.

These rely on pytest plugins:

    pytest-black
    pytest-flake8
    pytest-isort
"""
# The plugins are discovered automatically by pytest – no code needed.
