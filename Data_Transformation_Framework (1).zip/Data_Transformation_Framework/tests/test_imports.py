"""
Smoke-test: every .py file must import without error.
"""
from tests.conftest import iter_module_names, import_module


def test_every_module_importable():
    bad = []
    for mod in iter_module_names():
        try:
            import_module(mod)
        except Exception as exc:  # noqa: BLE001
            bad.append(f"{mod}: {exc}")
    assert not bad, "Import errors:\n" + "\n".join(bad)
