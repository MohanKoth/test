"""
Fail when any non‑whitelisted function exceeds McCabe complexity 12.
"""
from pathlib import Path
from radon.complexity import cc_visit

WHITELIST = {
    # dispatcher‑style helpers that are naturally long
    "utils/etl_utils.py:apply_single_rule",
    "utils/etl_utils.py:apply_join_filter_rules",
    "target_loader/target_loader.py:write_target",
}

THRESHOLD = 12


def test_cyclomatic_complexity_under_threshold():
    offenders = []
    for path in Path(".").rglob("*.py"):
        if "tests" in path.parts or path.name.startswith("__"):
            continue

        rel_path = path.as_posix()
        source = path.read_text()
        for block in cc_visit(source):
            fname = f"{rel_path}:{block.name}"
            if fname in WHITELIST:
                continue
            if block.complexity > THRESHOLD:
                offenders.append(
                    f"{rel_path}:{block.lineno} - {block.name}() has CC {block.complexity}"
                )

    assert not offenders, "High-complexity code:\n" + "\n".join(offenders)
